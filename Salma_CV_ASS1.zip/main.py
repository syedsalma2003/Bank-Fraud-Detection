
import cv2
import numpy as np

def load_image(image_path):
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    return image

def detect_lines(image):
    edges = cv2.Canny(image, 50, 150, apertureSize=3)
    lines = cv2.HoughLinesP(edges, 1, np.pi / 180, threshold=100, minLineLength=100, maxLineGap=10)
    return lines

def calculate_lengths(lines):
    lengths = []
    for line in lines:
        for x1, y1, x2, y2 in line:
            length = np.sqrt((x2 - x1)**2 + (y2 - y1)**2)
            lengths.append(length * 0.1)
    return lengths

def calculate_angle(lines):
    x1, y1, x2, y2 = lines[0][0]
    line1 = (x2 - x1, y2 - y1)

    x1, y1, x2, y2 = lines[1][0]
    line2 = (x2 - x1, y2 - y1)

    angle = np.arccos(np.dot(line1, line2) / (np.linalg.norm(line1) * np.linalg.norm(line2)))
    angle_degrees = np.degrees(angle)
    return angle_degrees

def highlight_intersection(image, lines):
    intersection_image = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
    for line in lines:
        for x1, y1, x2, y2 in line:
            cv2.line(intersection_image, (x1, y1), (x2, y2), (0, 0, 255), 3)
    return intersection_image

def main():
    image_path = 'IMG_20240709_160953.jpg'
    image = load_image(image_path)
    lines = detect_lines(image)
    lengths = calculate_lengths(lines)
    angle = calculate_angle(lines)
    intersection_image = highlight_intersection(image, lines)
    
    # Save the intersection image
    cv2.imwrite('intersection_image.jpg', intersection_image)
    
    print(f"Lengths of the pencils: {lengths} mm")
    print(f"Angle between the pencils: {angle} degrees")

if __name__ == '__main__':
    main()
